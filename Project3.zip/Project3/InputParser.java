import java.io.*;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.TreeSet;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class InputParser {
	public static void main(String args[])throws IOException {
		//All files are read into inputFile Array.
		File[] inputFile = new File("/Users/yodha/Documents/workspace/SearchEngine/src/ft911").listFiles();
		String text = "";
		String punc = "[\\p{Punct}]";
		HashSet<String> stopWords = new HashSet<String>();
		TreeSet<String> terms = new TreeSet<String>();
		long start_Time = System.currentTimeMillis();
		int val =0;
		
		//stopword file is read.
		File inputStop = new File("/Users/yodha/Documents/workspace/SearchEngine/src/stopwordlist.txt");
		FileReader inputStopReader = new FileReader(inputStop);
		BufferedReader inputStopBufferedReader = new BufferedReader(inputStopReader);
		HashMap<Integer, String> docID = new HashMap<Integer,String>();
		HashMap<Integer, String> tokenID = new HashMap<Integer,String>();
		HashMap<Integer, HashMap<String, Integer>> maps = new HashMap<>();
		String currentLine="";
		String stopWordInput="";
		Porter stemmer = new Porter();
		//Stopwords are read and spaces are removed and added to stopWords hashset.
		while ((stopWordInput = inputStopBufferedReader.readLine()) != null) {
			stopWords.add(stopWordInput.replaceAll("\\s",""));
		}
		inputStopReader.close();
		for(int i=0;i<inputFile.length;i++) {
			FileReader currentFile = new FileReader(inputFile[i]);
			BufferedReader currentFileReader = new BufferedReader(currentFile);
			while ((currentLine = currentFileReader.readLine()) != null) 
			{
				if(currentLine.contains("<DOCNO>")) {
					//Fetching document number from the line using Pattern class.
					Pattern pattern= Pattern.compile(Pattern.quote("<DOCNO>")+"(.*?)"+Pattern.quote("</DOCNO>"));
					Matcher match = pattern.matcher(currentLine);
					while(match.find())	{
						//Key for each document is taken as the number at the end of the document name.
						Pattern pattern1 = Pattern.compile(Pattern.quote("FT911-")+"(.*)");
						Matcher match1 = pattern1.matcher(match.group(1));
						while(match1.find()) {
							val = Integer.parseInt(match1.group(1));
							docID.put(Integer.parseInt(match1.group(1)), match.group(1));
							//System.out.println(docID.get(val));						
							}
					}
				}	
				//Each line in text is read.
				if(currentLine.contains("<TEXT>")) 
				{
					HashMap<String, Integer> innerFwd = new HashMap<String,Integer>(); //termID
					while(!(text=currentFileReader.readLine()).equals("</TEXT>")) 
					{
						//punctuation is replaced by space and converted to lower case.
						text = text.toLowerCase().replaceAll(punc, " ").replaceAll("\\n", "");
						String reg= "(.)*(\\d)(.)*";//to check words that contain digits.
						Pattern p=Pattern.compile(reg);
						String[] tokens = text.split(" "); //tokens array contains all input tokens.
						//Removing words that contain digits.
						for(int k=0;k<tokens.length;k++) {
							Matcher check=p.matcher(tokens[k]);
							if(!check.matches() && !tokens[k].isEmpty()  && !stopWords.contains(tokens[k]))
							{
								//Stemming is performed and stored to terms TreeSet.
								String stem= stemmer.stripAffixes(tokens[k]);
								if(!stem.isEmpty()){
									// Check if the term in the document is already added to the hashmap.
									if(innerFwd.containsKey(stem)){
										// If already contains then fetch and increment the frequency count.
										innerFwd.put(stem,(innerFwd.get(stem))+1);
									}
									else{
										// Else add the term to the hashmap with count as 1.
										innerFwd.put(stem, 1);
									}
									terms.add(stem);
								}
							}
						}
					}
					//Finally add all the terms in the document along with its frequency into maps hashmap.
					maps.put(val,new HashMap<String,Integer>(innerFwd));	
				}
			}
			currentFile.close();
			currentFileReader.close();			
		}
		System.out.println("Total Words:"+terms.size());
		//TreeSet is stored into HashMap to represent as Word Dictionary.
		int count=1;
		for(String tok:terms) {
			tokenID.put(count++, tok);
		}
		System.out.println("Total documents:"+docID.size());
		//Keeping track of reversed hashmap to make the access easier.
		HashMap<String, Integer> reversedtokenID = new HashMap<String, Integer>();
		for (Integer key : tokenID.keySet()){
		    reversedtokenID.put(tokenID.get(key), key);
		}
		//Output is written to parser_output file.
		FileWriter fileWrite = new FileWriter("parser_output.txt");
		//Word dictionary is written to parser_output in sorted order.
		for(int tokKey=1;tokKey<=tokenID.size();tokKey++)
			fileWrite.write(tokenID.get(tokKey)+"\t"+tokKey+"\n");
		//File dictionary is written to parser_output in sorted order.
		for(int docKey=1;docKey<=docID.size();docKey++)
			fileWrite.write(docID.get(docKey)+"\t"+docKey+"\n");
		//Forward Index is written to forward_index file.
		FileWriter fileWrite1 = new FileWriter("forward_index.txt");
		HashMap<Integer,Double> docLength = new HashMap<Integer,Double>();
		//Getting all the documentIDs.
		for (Integer ii: maps.keySet()) {
			fileWrite1.write("\n\n"+ii+":\n");
			double va=0.0;
			
			//Getting all the words with its frequencies in each document.
			for (String name: maps.get(ii).keySet()){
				fileWrite1.write(reversedtokenID.get(name) + ":" + maps.get(ii).get(name)+"; ");
				va = va+((maps.get(ii).get(name))*maps.get(ii).get(name));
			}
			va = Math.sqrt(va);
			docLength.put(ii,va);
		} 
		// Inverted Index is written to inverted_index file.
		FileWriter fileWrite2 = new FileWriter("inverted_index.txt");
		for(int tokKey=1;tokKey<=tokenID.size();tokKey++) {
			String check = tokenID.get(tokKey);
			fileWrite2.write("\n\n"+reversedtokenID.get(check)+":\n");
			//Get all the document IDs and check if it contains the term.
			for(Integer ii:maps.keySet()) {
				if(maps.get(ii).containsKey(check))
					fileWrite2.write(ii+":"+maps.get(ii).get(check)+";");
			}
		}
		fileWrite.close();
		fileWrite1.close();
		fileWrite2.close();
		// Term is taken as the input while execution to get all its details.
		long end_Time = System.currentTimeMillis();
		long indexing_Time = (end_Time-start_Time)/1000;
		System.out.println("Indexing Time in seconds : "+indexing_Time);
		System.out.println("Size of the maps array is:"+maps.size());
		String input = args[0];
		input = stemmer.stripAffixes(input);
		if(reversedtokenID.containsKey(input))
		{
			//System.out.println("Word ID for:"+input+" is:"+reversedtokenID.get(input));
			for(Integer ii:maps.keySet()) {
				if(maps.get(ii).containsKey(input))
					System.out.println("Doc"+ii+":"+maps.get(ii).get(input)+";");
			}
		}
		else
		{
			System.out.println("Term not found in the collection");
		}
		
		//Main Query alone is considered.
				String current_Line="";
				String current_Lines="";
				String current_Liness="";
				String current_Linesss="";
				FileReader current_File = new FileReader("/Users/yodha/Documents/workspace/SearchEngine/src/topics.txt");
				BufferedReader current_FileReader = new BufferedReader(current_File);
				HashMap<Integer, String> queryID = new HashMap<Integer,String>();
				
				while ((current_Line = current_FileReader.readLine()) != null) 
				{
					if(current_Line.contains("<num>")) {
						current_Line = current_Line.replaceAll("\\D+","");
						current_Lines = current_FileReader.readLine();
						if(current_Lines.contains("<title>")) {
							current_Lines = current_Lines.replaceAll("<title> ","");
						}
						current_Lines = current_Lines.toLowerCase().replaceAll(punc, " ").replaceAll("\n", " ");
						queryID.put(Integer.parseInt(current_Line),current_Lines);
					}
				}

		//For main query and description
		/*String current_Line="";
		String current_Lines="";
		String current_Liness="";
		String current_Linesss="";
		FileReader current_File = new FileReader("/Users/yodha/Documents/workspace/SearchEngine/src/topics.txt");
		BufferedReader current_FileReader = new BufferedReader(current_File);
		HashMap<Integer, String> queryID = new HashMap<Integer,String>();
		
		while ((current_Line = current_FileReader.readLine()) != null) 
		{
			if(current_Line.contains("<num>")) {
				current_Line = current_Line.replaceAll("\\D+","");
				current_Lines = current_FileReader.readLine();
				if(current_Lines.contains("<title>")) {
					current_Lines = current_Lines.replaceAll("<title> ","");
				}
				int jet = 0;
				while((current_Liness = current_FileReader.readLine())!=null){
					if(current_Liness.contains("<narr>"))
						break;
					if(current_Liness.contains("<desc>")){
						current_Liness = current_FileReader.readLine();
					
						jet = 1;
					}
					if(jet == 1){
						
						current_Lines = current_Lines+" "+current_Liness;
					}
				}
				
				current_Lines = current_Lines.toLowerCase().replaceAll(punc, " ").replaceAll("\n", " ");
				//System.out.println(current_Lines);
				queryID.put(Integer.parseInt(current_Line),current_Lines);
			}
		}*/
				
				
		//Main Query and Narration
		/*String current_Line="";
		String current_Lines="";
		String current_Liness="";
		String current_Linesss="";
		FileReader current_File = new FileReader("/Users/yodha/Documents/workspace/SearchEngine/src/topics.txt");
		BufferedReader current_FileReader = new BufferedReader(current_File);
		HashMap<Integer, String> queryID = new HashMap<Integer,String>();
		
		while ((current_Line = current_FileReader.readLine()) != null) 
		{
			if(current_Line.contains("<num>")) {
				current_Line = current_Line.replaceAll("\\D+","");
				current_Lines = current_FileReader.readLine();
				if(current_Lines.contains("<title>")) {
					current_Lines = current_Lines.replaceAll("<title> ","");
				}
				int jet = 0;
				while((current_Liness = current_FileReader.readLine())!=null){
					if(current_Liness.contains("</top>"))
						break;
					if(current_Liness.contains("<narr>")){
						current_Liness = current_FileReader.readLine();
					
						jet = 1;
					}
					if(jet == 1){
						
						current_Lines = current_Lines+" "+current_Liness;
					}
				}
				
				current_Lines = current_Lines.toLowerCase().replaceAll(punc, " ").replaceAll("\n", " ");
				System.out.println(current_Lines);
				queryID.put(Integer.parseInt(current_Line),current_Lines);
			}
		}*/
		
		
		String zzzz="";
		int track=0;
		double score=0;
		//Output file.
		FileWriter outputFile = new FileWriter("vsm_output.txt");
		for(Integer i:queryID.keySet()) {
			//System.out.println("Query"+i+":"+queryID.get(i)+";");
			String[] tokensss = queryID.get(i).split(" ");
			HashMap<Integer, Integer> queryTerm = new HashMap<Integer,Integer>();
			HashMap<String, Integer> ignoreTerm = new HashMap<String,Integer>();
			for(int zzz=0;zzz<tokensss.length;zzz++){
				//System.out.println(i+" :"+tokensss[zzz]);
				if(tokensss[zzz].length()>1){
					//Stemming each word.
					zzzz = stemmer.stripAffixes(tokensss[zzz]);
					//System.out.println(zzzz);
					if(reversedtokenID.containsKey(zzzz)){
						//System.out.println(zzzz);
						track=reversedtokenID.get(zzzz);
						if(!queryTerm.containsKey(track)){
							queryTerm.put(track,1);
						}
						else{
							int getme=queryTerm.get(track);
							getme++;
							queryTerm.put(track, getme);
						}
						
					}
					else{
						if(!ignoreTerm.containsKey(tokensss[zzz])){
							ignoreTerm.put(tokensss[zzz], 1);
						}
						else{
							int getme=ignoreTerm.get(tokensss[zzz]);
							getme++;
							ignoreTerm.put(tokensss[zzz], getme);
						}
							
					}
				}
				
			}
			//System.out.println(queryTerm.size());
			int termCount=0;
			int termCounts=0;
			for(Integer kkk:queryTerm.keySet()){
				termCount = termCount+((queryTerm.get(kkk))*(queryTerm.get(kkk)));
			}
			for(String kkk:ignoreTerm.keySet()){
				termCounts = termCounts+((ignoreTerm.get(kkk))*(ignoreTerm.get(kkk)));
			}
			termCount = termCount+termCounts;
			double length = Math.sqrt(termCount);
			Map<Integer,Double> docScores = new HashMap<Integer,Double>();
			// Compare the query with each document.
			for (Integer ii: maps.keySet()) {
				
				
				if(ii<5369){
				for(Integer kkz:queryTerm.keySet())
				{
					//System.out.println(maps.get(ii).get(reversedtokenID.get(kkz)));
					//Doc Frequency
					int rem =0;
					if(maps.get(ii).containsKey(tokenID.get(kkz))){
						
						
						for(Integer zi:maps.keySet()){
							
							if(maps.get(zi).containsKey(tokenID.get(kkz))){
								rem++;
							}
							
						}
						//System.out.println(rem);
						int queryVal = queryTerm.get(kkz);
						//System.out.println(queryVal);
						double queryVal1 = queryVal*(Math.log10((double)maps.size()/rem));
						//System.out.println(queryVal1);
						double queryVal2 = queryVal1/length;
						//System.out.println(queryVal2);
						
						int docVal = maps.get(ii).get(tokenID.get(kkz));
						//System.out.println(docVal);
						double docVal1 = docVal*(Math.log10((double)maps.size()/rem));
						//System.out.println(docVal1);
						double docVal2 = docVal1/docLength.get(ii);
						//System.out.println(docVal2);
						// Calculating score using the forumla given in the algorithm.
						score = score + (queryVal2*docVal2);
					
					}
				}
				//Considering documents with only above 0 scores.
				if(score>0){
				docScores.put(ii,score);
				}
				score = 0.0;
				}
			}
			//To sort the hashmap by value.
	        Map<Integer, Double> sortedMap =
	               docScores.entrySet().stream()
	                        .sorted(Map.Entry.comparingByValue(Collections.reverseOrder()))
	                        .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
	                                (e1, e2) -> e1, LinkedHashMap::new));
	        int idp = 1;
	        //Output file.
	        for(Integer qwe:sortedMap.keySet())
	        {
	        	outputFile.write(i+"\tft911-"+qwe+"\t"+idp+"\t"+sortedMap.get(qwe)+"\n");
	        	idp++;
	        }
		}
		outputFile.close();
	}
}